"""A module containing constant values for infrastructure layer."""

EXPIRATION_MINUTES = 60
SECRET_KEY = "s3cr3t"
ALGORITHM = "HS256"
