docker exec -it db psql -U postgres
\c app;

INSERT INTO users (email, name, password) VALUES
    ('temp@mail.pl', 'Kamil', 'haslo'),
    ('bartek@mail.pl', 'Bartek', 'haslo123'),
    ('tomek@mail.pl', 'Tomek', 'password');

INSERT INTO continents (name, alias) VALUES
    ('Europa', 'EU'),
    ('Ameryka Północna', 'NA'),
    ('Azja', 'AS');

INSERT INTO countries (name, inhabitants, language, area, pkb, continent_id, user_name, user_id) VALUES
    ('Polska', 37, 'polski', 312, 811, 1, 'Kamil', (SELECT id FROM users WHERE name = 'Kamil')),
    ('Niemcy', 84, 'niemiecki', 357, 4456, 1, 'Kamil',(SELECT id FROM users WHERE name = 'Kamil')),
    ('USA', 334, 'angielski', 9834, 27360, 2, 'Kamil',(SELECT id FROM users WHERE name = 'Kamil')),
    ('Chiny', 1440, 'chiński', 9597, 16642, 3, 'Kamil', (SELECT id FROM users WHERE name = 'Bartek'));

INSERT INTO visited (user_name, country_name) VALUES 
    ('Kamil', 'Włochy'),
    ('Kamil', 'Austria'),
    ('Bartek', 'Austria'),
    ('Tomek', 'Polska');

INSERT INTO favourite (user_name, country_name) VALUES 
    ('Kamil', 'Włochy'),
    ('Bartek', 'Austria'),
    ('Tomek', 'Polska'),
    ('Tomek', 'USA');
