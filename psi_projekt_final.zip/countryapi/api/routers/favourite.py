"""A module containing favourite endpoints."""
from typing import Iterable, Any
from dependency_injector.wiring import inject, Provide
from fastapi import APIRouter, Depends, HTTPException

from countryapi.container import Container
from countryapi.core.domain.favourite import Favourite, FavouriteIn
from countryapi.infrastructure.services.ifavourite import IFavouriteService

router = APIRouter()


@router.post("/create", response_model=Favourite, status_code=201)
@inject
async def create_favourite(
    favourite: FavouriteIn,
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> dict:
    """An endpoint for adding new favourite.

    Args:
        favourite (FavouriteIn): The favourite data.
        service (IFavouriteService, optional): The injected service dependency.

    Returns:
        dict: The new favourite attributes.
    """
    new_favourite = await service.add_favourite(favourite)

    return new_favourite.model_dump() if new_favourite else {}

@router.get("/{favourite_id}", response_model=Favourite, status_code=200)
@inject
async def get_favourite_by_id(
    favourite_id: int,
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> dict:
    """An endpoint for getting favourite details by id.

    Args:
        favourite_id (int): The id of the favourite.
        service (IFavouriteService, optional): The injected service dependency.

    Raises:
        HTTPException: 404 if favourite does not exist.

    Returns:
        dict: The requested favourite attributes.
    """
    if favourite := await service.get_favourite_by_id(favourite_id):
        return favourite.model_dump()

    raise HTTPException(status_code=404, detail="Favourite not found")

@router.get("/all/{all}", response_model=Iterable[Favourite], status_code=200)
@inject
async def get_all_favourites(
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> Iterable:
    """An endpoint for getting all favourites.

    Args:
        service (IFavouriteService, optional): The injected service dependency.

    Returns:
        Iterable: The favourites attributes collection.
    """
    favourites = await service.get_all_favourites()

    return favourites


@router.get("/ranking/{ranking}", response_model=Any, status_code=200)
@inject
async def get_ranking(
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> Iterable:
    """An endpoint for getting favourites ranking.

    Args:
        service (IFavouriteService, optional): The injected service dependency.

    Returns:
        Iterable: The favourite countries ranking.
    """
    ranking = await service.get_ranking()

    return ranking

@router.get("/country/{country_name}", response_model=Iterable[Favourite], status_code=200)

@inject
async def get_favourite_by_country(
    country_name: str,
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> Iterable:
    """An endpoint for getting favourite details by country_name.

    Args:
        country_name (str): The name of the country.
        service (IFavouriteService, optional): The injected service dependency.

    Returns:
        Iterable: The favourites attributes collection.
    """
    favourite = await service.get_favourite_by_country(country_name)

    return favourite


@router.get("/user/{user_name}", response_model=Iterable[Favourite], status_code=200)

@inject
async def get_favourite_by_user(
    user_name: str,
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> Iterable:
    """An endpoint for getting favourite details by username.

    Args:
        user_name (str): The name of the user.
        service (IFavouriteService, optional): The injected service dependency.

    Returns:
        Iterable: The favourites attributes collection.
    """
    favourite = await service.get_favourite_by_user(user_name)

    return favourite

@router.put("/{favourite_id}", response_model=Favourite, status_code=201)
@inject
async def update_favourite(
    favourite_id: int,
    updated_favourite: FavouriteIn,
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> dict:
    """An endpoint for updating favourite data.

    Args:
        favourite_id (int): The id of the favourite.
        updated_favourite (FavouriteIn): The updated favourite details.
        service (IFavouriteService, optional): The injected service dependency.

    Raises:
        HTTPException: 404 if favourite does not exist.

    Returns:
        dict: The updated favourite details.
    """
    if await service.get_favourite_by_id(favourite_id=favourite_id):
        new_updated_favourite = await service.update_favourite(
            favourite_id=favourite_id,
            data=updated_favourite,
        )
        return new_updated_favourite.model_dump() if new_updated_favourite \
            else {}

    raise HTTPException(status_code=404, detail="Favourite not found")


@router.delete("/{favourite_id}", status_code=204)
@inject
async def delete_favourite(
    favourite_id: int,
    service: IFavouriteService = Depends(Provide[Container.favourite_service]),
) -> None:
    """An endpoint for deleting favourite.

    Args:
        favourite_id (int): The id of the favourite.
        service (IFavouriteService, optional): The injected service dependency.

    Raises:
        HTTPException: 404 if favourite does not exist.

    Returns:
        dict: Empty if operation finished.
    """

    if await service.get_favourite_by_id(favourite_id=favourite_id):
        await service.delete_favourite(favourite_id)
        return

    raise HTTPException(status_code=404, detail="Favourite not found")
