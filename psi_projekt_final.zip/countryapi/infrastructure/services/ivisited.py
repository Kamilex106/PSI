"""Module containing visited service abstractions."""
from abc import ABC, abstractmethod
from typing import Iterable

from countryapi.core.domain.visited import Visited, VisitedIn


class IVisitedService(ABC):
    """An abstract class representing protocol of visited repository."""
    @abstractmethod
    async def get_visited_by_id(self, visited_id: int) -> Visited | None:
        pass
    """The abstract getting a visited from the repository.

    Args:
        visited_id (int): The id of the visited.

    Returns:
        Visited | None: The visited data if exists.
    """


    @abstractmethod
    async def get_visited_by_country(self, country_name: str) -> Iterable[Visited]:
        pass
    """The abstract getting a visited from the repository.

    Args:
        country_name (str): The country_name of the country.

    Returns:
        Iterable[Visited]: The collection of all visited by country_name.
    """

    @abstractmethod
    async def get_visited_by_user(self, user_name: str) -> Iterable[Visited]:
        pass
    """The abstract getting a visited from the repository.

    Args:
        user_name (str): The user_name of the user.

    Returns:
        Iterable[Visited]: The collection of all visited by user_name.
    """

    @abstractmethod
    async def add_visited(self, data: VisitedIn) -> Visited | None:
        pass
    """The abstract adding new visited to the repository.

    Args:
        data (VisitedIn): The attributes of the visited.

    Returns:
        Visited | None: The newly created visited.
    """

    @abstractmethod
    async def update_visited(
        self,
        visited_id: int,
        data: VisitedIn,
    ) -> Visited | None:
        pass
    """The abstract updating visited data in the repository.

    Args:
        visited_id (int): The visited id.
        data (VisitedIn): The attributes of the visited.

    Returns:
        Visited | None: The updated visited.
    """

    @abstractmethod
    async def delete_visited(self, visited_id: int) -> bool:
        pass
    """The abstract removing visited from the repository.

    Args:
        visited_id (int): The visited id.

    Returns:
        bool: Success of the operation.
    """

