"""Module containing visited-related domain models."""
from pydantic import BaseModel, ConfigDict


class VisitedIn(BaseModel):
    """Model representing visited DTO attributes."""
    user_name: str
    country_name: str



class Visited(VisitedIn):
    """Model representing visited attributes in the database."""
    id: int

    model_config = ConfigDict(from_attributes=True, extra="ignore")


