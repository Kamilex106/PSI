API_SENSOR_URL = "https://api.gios.gov.pl/pjp-api/rest/data/getData/{sensor_id}"
SENSOR_ID = 5766
