from dependency_injector import containers, providers

from repositories.posts_repository import PostRepository
from services.post_service import PostService

from repositories.comments_repository import CommentRepository
from services.comment_service import CommentService


class Container(containers.DeclarativeContainer):
    config = providers.Configuration()

    repository = providers.Singleton(
        PostRepository,
    )

    # C_repository = providers.Singleton(
    #     CommentRepository,
    # )

    service = providers.Factory(
        PostService,
        repository=repository,
    )


    # service = providers.Factory(
    #     CommentService,
    #     C_repository=C_repository,
    # )