from typing import Iterable

from domains.comments import CommentRecord
from repositories.comments_repository import CommentRepository
from services.icomment_service import ICommentService

class CommentService(ICommentService):
    repository: CommentRepository

    def __init__(self, repository: CommentRepository) -> None:
        self.repository = repository

    async def get_all_comments(self):
        return await self.repository.get_all_comments()

    async def get_all_comments_json(self):
        return await self.repository.get_all_comments_json()

    async def get_all_comments_by_title(self, title: str):
        before_fil = await self.repository.get_all_comments()
        comment_list = []
        for comment in before_fil:
            if title in comment.title:
                comment_list.append(comment)
        return comment_list

    async def get_all_comments_by_body(self, body: str):
        before_fil = await self.repository.get_all_comments()
        comment_list = []
        for comment in before_fil:
            if body in comment.body:
                comment_list.append(comment)
        return comment_list