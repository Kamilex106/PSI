from abc import ABC
from typing import Iterable
from domains.comments import CommentRecord

class ICommentRepository(ABC):

    async def get_all_comments(self) -> Iterable[CommentRecord] | None:
        pass
