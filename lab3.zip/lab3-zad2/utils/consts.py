API_URL_posts = "https://jsonplaceholder.typicode.com/posts"
API_URL_comments = "https://jsonplaceholder.typicode.com/comments"
