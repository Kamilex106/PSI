# Country API

Aplikacja przeznaczona do ...

## Lista funkcjonalności
...

## Stos technologiczny
- Python 3.12.7
- PostgreSQL 17.0
- Docker
