EXPIRATION_MINUTES = 60
SECRET_KEY = "s3cr3t"  # TODO: -> random generation - it's safe
ALGORITHM = "HS256"
