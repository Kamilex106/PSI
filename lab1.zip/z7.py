import asyncio
from asyncio import gather


def krojenie():
    fetch(2)
    print("Krojenie")

def gotowanie():
    gather().
    print("gotowanie")

def smazenie():
    gather()
    print("smazenie")


def posilek(nazwa):
    if nazwa=="spaghetti":
        krojenie()
        gotowanie()
        smazenie()
async def fetch(delay: int) -> None:
    await asyncio.sleep(delay)

with asyncio.Runner() as runner:
    asyncio.run(posilek("spaghetti"))

