import asyncio


async def main() -> None:
    await asyncio.sleep(3)
    print("Korutyna 1")
    await(kor1())


async def kor1() -> None:
    await asyncio.sleep(1)
    print("Korutyna 2")



with asyncio.Runner() as runner:
    asyncio.run(main())
