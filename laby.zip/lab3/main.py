from dependency_injector.wiring import Provide

import asyncio

from container import Container
from repositories.posts_repository import PostRepository
from services.ipost_service import IPostService
from utils import consts


async def main(
        service: IPostService = Provide[Container.service],
) -> None:
    posts_body = await service.get_all_posts()
    print(posts_body)


if __name__ == "__main__":
    container = Container()
    container.wire(modules=[__name__])

    asyncio.run(main())
