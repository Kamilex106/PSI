from abc import ABC

class IPostService(ABC):
    async def get_posts_body(self) -> str:
        pass

    async def get_all_posts(self) -> str:
        pass