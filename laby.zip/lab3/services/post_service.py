from repositories.posts_repository import PostRepository
from services.ipost_service import IPostService

class PostService(IPostService):
    repository: PostRepository

    def __init__(self, repository: PostRepository) -> None:
        self.repository = repository

    async def get_all_posts(self):

        return await self.repository.get_all_posts()

    async def get_posts_body(self):

        return await self.repository.get_all_posts()
