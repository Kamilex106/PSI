import aiohttp
from typing import Iterable

from utils import consts
from domains.posts import PostRecord
from repositories.ipost_repository import IPostRepository


class PostRepository(IPostRepository):

    async def get_all_posts(self) -> Iterable[PostRecord] | None:
        all_posts = await self._get_posts()
        #parsed_params = await self._parse_params(all_params)

        return all_posts

    async def _get_posts(self) -> Iterable[dict] | None:
        async with aiohttp.ClientSession() as session:
            async with session.get(consts.API_URL.format()) as response:
                if response.status != 200:
                    return None

                return await response.json()
