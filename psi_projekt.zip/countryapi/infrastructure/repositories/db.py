countries: list = []
continents: list = []

